SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS Grados;
DROP TABLE IF EXISTS Asignaturas;
DROP TABLE IF EXISTS Grupos;
DROP TABLE IF EXISTS Alumnos;
DROP TABLE IF EXISTS GruposAlumnos;
DROP TABLE IF EXISTS Profesores;
DROP TABLE IF EXISTS Departamentos;
DROP TABLE IF EXISTS Despachos;
DROP TABLE IF EXISTS Aulas;
DROP TABLE IF EXISTS Tutorias;
DROP TABLE IF EXISTS Notas;

DROP TABLE IF EXISTS Citas ;
DROP TABLE IF EXISTS Imparte ;
DROP TABLE IF EXISTS AlumnoCita ;
DROP TABLE IF EXISTS CitaTutoria ;
DROP TABLE IF EXISTS ProfesorTutoria ;
DROP TABLE IF EXISTS DespachoProfesor ;

DROP TABLE IF EXISTS ProfesorDepartamento ;
DROP TABLE IF EXISTS DepartamentoAsignatura ;

DROP TABLE IF EXISTS GrupoAsignatura ;
DROP TABLE IF EXISTS AsignaturaGrado ;
DROP TABLE IF EXISTS AlumnoNota ;
DROP TABLE IF EXISTS NotaGrupo ;



SET FOREIGN_KEY_CHECKS=1;


CREATE TABLE Grados(
	gradoId INT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(60) NOT NULL UNIQUE,
	anyos INT DEFAULT(4) NOT NULL,
	nCreditos INT  NOT NULL,
	PRIMARY KEY (gradoId),
	
);


CREATE TABLE Asignaturas(
	asignaturaId INT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(100) NOT NULL UNIQUE,
	acronimo VARCHAR(8) NOT NULL UNIQUE,
	creditos INT NOT NULL,
	curso INT NOT NULL,
	tipo VARCHAR(20) NOT NULL,
	gradoId INT NOT NULL,
	PRIMARY KEY (asignaturaId),
	FOREIGN KEY (gradoId) REFERENCES Grados (gradoId),
	CONSTRAINT negativeSubjectcreditos CHECK (creditos > 0),
	CONSTRAINT invalidSubjectcurso CHECK (curso > 0 AND curso < 6),
	CONSTRAINT invalidSubjecttipo CHECK (tipo IN ('Formacion Basica',
																 'Optativa',
																 'Obligatoria'))
);
CREATE TABLE Despachos(
	despachoId INT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(100) NOT NULL UNIQUE,
	Planta INT NOT NULL UNIQUE,
	PRIMARY KEY(despachoId)
	);
CREATE TABLE Aulas(
	aulaId INT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(100) NOT NULL UNIQUE,
	planta INT NOT NULL UNIQUE,
	megafonia BOOLEAN NOT NULL,
	proyector BOOLEAN NOT NULL,
	teoria BOOLEAN NOT NULL,
	laboratorio BOOLEAN NOT NULL,
	PRIMARY KEY(aulaId)
	);


CREATE TABLE Grupos(
	grupoId INT NOT NULL AUTO_INCREMENT,
	asignaturaId INT NOT NULL,
	nombre VARCHAR(30) NOT NULL,
	anyos INT NOT NULL,
	creditos INT NOT NULL,
	
	PRIMARY KEY (grupoId),
	FOREIGN KEY (asignaturaId) REFERENCES Asignaturas (asignaturaId),
	UNIQUE (nombre, anyos, asignaturaId),
	CONSTRAINT negativeGroupanyos CHECK (anyos > 0),
	CONSTRAINT invalidGroupactividad CHECK (actividad IN ('Teoria',
																		 'Laboratorio'))
);

CREATE TABLE Alumnos(
	alumnoId INT NOT NULL AUTO_INCREMENT,
	dni CHAR(9) NOT NULL UNIQUE,
	nombre VARCHAR(100) NOT NULL,
	apellidos VARCHAR(100) NOT NULL,
	metodoAcceso VARCHAR(30) NOT NULL,
	birthDate DATE NOT NULL,
	email VARCHAR(250) NOT NULL ,
	PRIMARY KEY (alumnoId),
	CONSTRAINT invalidmetodoAcceso CHECK (metodoAcceso IN ('Selectividad',
																					  'Ciclo',
																					  'Mayor',
																					  'Titulado Extranjero'))
);

CREATE TABLE GruposAlumnos(
	grupoalumnoId INT NOT NULL AUTO_INCREMENT,
	grupoId INT NOT NULL,
	alumnoId INT NOT NULL,
	PRIMARY KEY (grupoalumnoId),
	FOREIGN KEY (grupoId) REFERENCES Grupos (grupoId) ON DELETE CASCADE,
	FOREIGN KEY (alumnoId) REFERENCES Alumnos (alumnoId),
	UNIQUE (grupoId, alumnoId)
);


CREATE TABLE Notas(
	notaId INT NOT NULL AUTO_INCREMENT,
	puntuacion DOUBLE NOT NULL,
	alumnoId INT NOT NULL,
	grupoId INT NOT NULL,
	PRIMARY KEY (notaId),
	FOREIGN KEY (alumnoId) REFERENCES Alumnos (alumnoId),
	FOREIGN KEY (grupoId) REFERENCES Grupos (grupoId) ON DELETE CASCADE
	
);
CREATE TABLE Departamentos(
	departamentoId INT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(100) NOT NULL UNIQUE,
	numeroAsiganturas INT NOT NULL,
	PRIMARY KEY(departamentoId)
	);

CREATE TABLE Profesores(
	profesorId INT NOT NULL AUTO_INCREMENT,
	despachoId INT NOT NULL,
	departamentoId INT NOT NULL,
	dni CHAR(9) NOT NULL UNIQUE,	
	nombre VARCHAR(100) NOT NULL ,
	apellidos VARCHAR(100) NOT NULL ,
	fechaNacimiento DATE NOT NULL ,
	emailProfesor VARCHAR(100) NOT NULL,
	categoria VARCHAR(100) NOT NULL,
	
	PRIMARY KEY (profesorId),
	FOREIGN KEY (despachoId) REFERENCES Despachos (despachoId),
	FOREIGN KEY (departamentoId) REFERENCES Departamentos (departamentoId),
	CONSTRAINT categoriaInvalida CHECK (categoria IN ('Catedratico',
																					  'Titular de Universidad',
																					  'Profesor Contrato Doctor',
																					  'Profesor Ayudante Doctor'))
);


CREATE TABLE Tutorias(
	tutoriaId INT NOT NULL AUTO_INCREMENT,
	profesorId INT NOT NULL,
	dia DATE NOT NULL,
	horaComienzo TIME NOT NULL,
	horaFin TIME NOT NULL,
	PRIMARY KEY(tutoriaId),
	FOREIGN KEY (profesorId) REFERENCES Profesores(profesorId)
);

CREATE TABLE Citas(
	citaId INT NOT NULL AUTO_INCREMENT,
	tutoriaId INT NOT NULL,
	alumnoId INT NOT NULL,
	hora TIME  NOT NULL,
	fecha DATE NOT NULL,
	PRIMARY KEY(citaId),
	FOREIGN KEY (tutoriaId) REFERENCES Tutorias(tutoriaId),
	FOREIGN KEY (alumnoId) REFERENCES Alumnos(alumnoId)
);
	

CREATE TABLE Imparte(
	ImparteId INT NOT NULL AUTO_INCREMENT ,
	creditos DOUBLE  NOT NULL,
	profesorId INT NOT NULL,
	grupoid INT NOT NULL, 
	PRIMARY KEY (ImparteId),
	FOREIGN KEY (profesorId) REFERENCES Profesores(profesorId),
	FOREIGN KEY (grupoid) REFERENCES Grupos(grupoid)

);
	
CREATE TABLE AlumnoCita(
	alumnoCitaId INT NOT NULL AUTO_INCREMENT,
	alumnoId INT NOT NULL,
	citaId INT NOT NULL,
	PRIMARY KEY (alumnoCitaId),
	FOREIGN KEY (alumnoId) REFERENCES Alumnos(alumnoId),
	FOREIGN KEY (citaId) REFERENCES Citas(citaId)

);

CREATE TABLE CitaTutoria(
	citaTutoriaId INT NOT NULL AUTO_INCREMENT ,
	citaId INT NOT NULL,
	tutoriaId INT NOT NULL,
	PRIMARY KEY (citaTutoriaId),
	FOREIGN KEY (citaId) REFERENCES Citas(citaId),
	FOREIGN KEY (tutoriaId) REFERENCES Tutorias(tutoriaId)

);


CREATE TABLE ProfesorTutoria(
	profesorTutoriaId INT NOT NULL AUTO_INCREMENT ,
	citaId INT NOT NULL,
	tutoriaId INT NOT NULL,
	PRIMARY KEY (profesorTutoriaId),
	FOREIGN KEY (citaId) REFERENCES Citas(citaId),
	FOREIGN KEY (tutoriaId) REFERENCES Tutorias(tutoriaId)
);


CREATE TABLE DespachoProfesor (
	despachoProfesorId INT NOT NULL AUTO_INCREMENT ,
	despachoId INT NOT NULL,
	profesorId INT NOT NULL,
	PRIMARY KEY (despachoProfesorId),
	FOREIGN KEY (despachoId) REFERENCES Despachos(despachoId),
	FOREIGN KEY (profesorId) REFERENCES Profesores(profesorId)

);



CREATE TABLE ProfesorDepartamento (
	profesorDepartamentoId INT NOT NULL AUTO_INCREMENT ,
	profesorId INT NOT NULL,
	departamentoId INT NOT NULL,
	PRIMARY KEY (profesorDepartamentoId),
	FOREIGN KEY (profesorId) REFERENCES Profesores(profesorId),
	FOREIGN KEY (departamentoId) REFERENCES Departamentos(departamentoId)

);




CREATE TABLE DepartamentoAsignatura(
	departamentoAsignaturaId INT NOT NULL AUTO_INCREMENT ,
	departamentoId INT NOT NULL,
	asignaturaId INT NOT NULL,
	PRIMARY KEY (departamentoAsignaturaId),
	FOREIGN KEY (departamentoId) REFERENCES Departamentos(departamentoId),
	FOREIGN KEY (asignaturaId) REFERENCES Asignaturas(asignaturaId)

);


  


CREATE TABLE AsignaturaGrado(
	asignaturaGradoId INT NOT NULL AUTO_INCREMENT ,
	asignaturaId INT NOT NULL,
	gradoId INT NOT NULL,
	PRIMARY KEY (asignaturaGradoId),
	FOREIGN KEY (asignaturaId) REFERENCES Asignaturas(asignaturaId),
	FOREIGN KEY (gradoId) REFERENCES Grados(gradoId)

);
CREATE TABLE GrupoAsignatura(
	grupoAsignaturaId INT NOT NULL AUTO_INCREMENT ,
	grupoId INT NOT NULL,
	asignaturaId INT NOT NULL,
	PRIMARY KEY (grupoAsignaturaId),
	FOREIGN KEY (grupoId) REFERENCES Grupos(grupoId),
	FOREIGN KEY (asignaturaId) REFERENCES Asignaturas(asignaturaId)

);
CREATE TABLE AlumnoNota (
	alumnoNotaId INT NOT NULL AUTO_INCREMENT ,
	alumnoId INT NOT NULL,
	notaId INT NOT NULL,
	PRIMARY KEY (alumnoNotaId),
	FOREIGN KEY (alumnoId) REFERENCES Alumnos(alumnoId),
	FOREIGN KEY (notaId) REFERENCES Notas(notaId)

);

CREATE TABLE NotaGrupo (
	notaGrupoId INT NOT NULL AUTO_INCREMENT ,
	notaId INT NOT NULL,
	grupoId INT NOT NULL,
	PRIMARY KEY (notaGrupoId),
	FOREIGN KEY (notaId) REFERENCES Notas(notaId),
	FOREIGN KEY (grupoId) REFERENCES Grupos(grupoId)

);


