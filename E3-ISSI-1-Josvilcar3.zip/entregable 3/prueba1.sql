-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.8-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para grados
CREATE DATABASE IF NOT EXISTS `grados` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci */;
USE `grados`;

-- Volcando estructura para tabla grados.alumnocita
DROP TABLE IF EXISTS `alumnocita`;
CREATE TABLE IF NOT EXISTS `alumnocita` (
  `alumnoCitaId` int(11) NOT NULL AUTO_INCREMENT,
  `alumnoId` int(11) NOT NULL,
  `citaId` int(11) NOT NULL,
  PRIMARY KEY (`alumnoCitaId`),
  KEY `alumnoId` (`alumnoId`),
  KEY `citaId` (`citaId`),
  CONSTRAINT `alumnocita_ibfk_1` FOREIGN KEY (`alumnoId`) REFERENCES `alumnos` (`alumnoId`),
  CONSTRAINT `alumnocita_ibfk_2` FOREIGN KEY (`citaId`) REFERENCES `citas` (`citaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.alumnocita: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alumnocita` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumnocita` ENABLE KEYS */;

-- Volcando estructura para tabla grados.alumnonota
DROP TABLE IF EXISTS `alumnonota`;
CREATE TABLE IF NOT EXISTS `alumnonota` (
  `alumnoNotaId` int(11) NOT NULL AUTO_INCREMENT,
  `alumnoId` int(11) NOT NULL,
  `notaId` int(11) NOT NULL,
  PRIMARY KEY (`alumnoNotaId`),
  KEY `alumnoId` (`alumnoId`),
  KEY `notaId` (`notaId`),
  CONSTRAINT `alumnonota_ibfk_1` FOREIGN KEY (`alumnoId`) REFERENCES `alumnos` (`alumnoId`),
  CONSTRAINT `alumnonota_ibfk_2` FOREIGN KEY (`notaId`) REFERENCES `notas` (`notaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.alumnonota: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alumnonota` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumnonota` ENABLE KEYS */;

-- Volcando estructura para tabla grados.alumnos
DROP TABLE IF EXISTS `alumnos`;
CREATE TABLE IF NOT EXISTS `alumnos` (
  `alumnoId` int(11) NOT NULL AUTO_INCREMENT,
  `metodoAcceso` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `dni` char(9) COLLATE latin1_spanish_ci NOT NULL,
  `firstNombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `surNombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `birthDate` date NOT NULL,
  `email` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`alumnoId`),
  UNIQUE KEY `dni` (`dni`),
  CONSTRAINT `invalidStudentmetodoAcceso` CHECK (`metodoAcceso` in ('Selectividad','Ciclo','Mayor','Titulado Extranjero'))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.alumnos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;

-- Volcando estructura para tabla grados.asignaturagrado
DROP TABLE IF EXISTS `asignaturagrado`;
CREATE TABLE IF NOT EXISTS `asignaturagrado` (
  `asignaturaGradoId` int(11) NOT NULL AUTO_INCREMENT,
  `asignaturaId` int(11) NOT NULL,
  `gradoId` int(11) NOT NULL,
  PRIMARY KEY (`asignaturaGradoId`),
  KEY `asignaturaId` (`asignaturaId`),
  KEY `gradoId` (`gradoId`),
  CONSTRAINT `asignaturagrado_ibfk_1` FOREIGN KEY (`asignaturaId`) REFERENCES `asignaturas` (`asignaturaId`),
  CONSTRAINT `asignaturagrado_ibfk_2` FOREIGN KEY (`gradoId`) REFERENCES `grados` (`gradoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.asignaturagrado: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `asignaturagrado` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignaturagrado` ENABLE KEYS */;

-- Volcando estructura para tabla grados.asignaturas
DROP TABLE IF EXISTS `asignaturas`;
CREATE TABLE IF NOT EXISTS `asignaturas` (
  `asignaturaId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `acronimo` varchar(8) COLLATE latin1_spanish_ci NOT NULL,
  `creditos` int(11) NOT NULL,
  `curso` int(11) NOT NULL,
  `tipo` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `gradoId` int(11) NOT NULL,
  PRIMARY KEY (`asignaturaId`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `acronimo` (`acronimo`),
  KEY `gradoId` (`gradoId`),
  CONSTRAINT `asignaturas_ibfk_1` FOREIGN KEY (`gradoId`) REFERENCES `grados` (`gradoId`),
  CONSTRAINT `negativeSubjectcreditos` CHECK (`creditos` > 0),
  CONSTRAINT `invalidSubjectcurso` CHECK (`curso` > 0 and `curso` < 6),
  CONSTRAINT `invalidSubjecttipo` CHECK (`tipo` in ('Formacion Basica','Optativa','Obligatoria'))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.asignaturas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `asignaturas` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignaturas` ENABLE KEYS */;

-- Volcando estructura para tabla grados.aulagrupo
DROP TABLE IF EXISTS `aulagrupo`;
CREATE TABLE IF NOT EXISTS `aulagrupo` (
  `aulaGrupoId` int(11) NOT NULL AUTO_INCREMENT,
  `aulaId` int(11) NOT NULL,
  `grupoId` int(11) NOT NULL,
  PRIMARY KEY (`aulaGrupoId`),
  KEY `aulaId` (`aulaId`),
  KEY `grupoId` (`grupoId`),
  CONSTRAINT `aulagrupo_ibfk_1` FOREIGN KEY (`aulaId`) REFERENCES `aulas` (`aulaId`),
  CONSTRAINT `aulagrupo_ibfk_2` FOREIGN KEY (`grupoId`) REFERENCES `grupos` (`grupoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.aulagrupo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `aulagrupo` DISABLE KEYS */;
/*!40000 ALTER TABLE `aulagrupo` ENABLE KEYS */;

-- Volcando estructura para tabla grados.aulas
DROP TABLE IF EXISTS `aulas`;
CREATE TABLE IF NOT EXISTS `aulas` (
  `aulaId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `planta` int(11) NOT NULL,
  `capacidad` int(11) NOT NULL,
  `tieneProyector` tinyint(1) NOT NULL,
  `tieneAltavoces` tinyint(1) NOT NULL,
  PRIMARY KEY (`aulaId`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `planta` (`planta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.aulas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `aulas` DISABLE KEYS */;
/*!40000 ALTER TABLE `aulas` ENABLE KEYS */;

-- Volcando estructura para tabla grados.citas
DROP TABLE IF EXISTS `citas`;
CREATE TABLE IF NOT EXISTS `citas` (
  `citaId` int(11) NOT NULL AUTO_INCREMENT,
  `tutoriaId` int(11) NOT NULL,
  `alumnoId` int(11) NOT NULL,
  `hora` time NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`citaId`),
  KEY `tutoriaId` (`tutoriaId`),
  KEY `alumnoId` (`alumnoId`),
  CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`tutoriaId`) REFERENCES `tutorias` (`tutoriaId`),
  CONSTRAINT `citas_ibfk_2` FOREIGN KEY (`alumnoId`) REFERENCES `alumnos` (`alumnoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.citas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `citas` DISABLE KEYS */;
/*!40000 ALTER TABLE `citas` ENABLE KEYS */;

-- Volcando estructura para tabla grados.citatutoria
DROP TABLE IF EXISTS `citatutoria`;
CREATE TABLE IF NOT EXISTS `citatutoria` (
  `citaTutoriaId` int(11) NOT NULL AUTO_INCREMENT,
  `citaId` int(11) NOT NULL,
  `tutoriaId` int(11) NOT NULL,
  PRIMARY KEY (`citaTutoriaId`),
  KEY `citaId` (`citaId`),
  KEY `tutoriaId` (`tutoriaId`),
  CONSTRAINT `citatutoria_ibfk_1` FOREIGN KEY (`citaId`) REFERENCES `citas` (`citaId`),
  CONSTRAINT `citatutoria_ibfk_2` FOREIGN KEY (`tutoriaId`) REFERENCES `tutorias` (`tutoriaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.citatutoria: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `citatutoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `citatutoria` ENABLE KEYS */;

-- Volcando estructura para tabla grados.degrees
DROP TABLE IF EXISTS `degrees`;
CREATE TABLE IF NOT EXISTS `degrees` (
  `degreeId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `years` int(11) NOT NULL DEFAULT 4,
  PRIMARY KEY (`degreeId`),
  UNIQUE KEY `name` (`name`),
  CONSTRAINT `invalidDegreeYear` CHECK (`years` >= 3 and `years` <= 5)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.degrees: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `degrees` DISABLE KEYS */;
REPLACE INTO `degrees` (`degreeId`, `name`, `years`) VALUES
	(1, 'Ingeniería del Software', 4),
	(2, 'Ingeniería del Computadores', 4),
	(3, 'Tecnologías Informáticas', 4);
/*!40000 ALTER TABLE `degrees` ENABLE KEYS */;

-- Volcando estructura para tabla grados.departamentoasignatura
DROP TABLE IF EXISTS `departamentoasignatura`;
CREATE TABLE IF NOT EXISTS `departamentoasignatura` (
  `departamentoAsignaturaId` int(11) NOT NULL AUTO_INCREMENT,
  `departamentoId` int(11) NOT NULL,
  `asignaturaId` int(11) NOT NULL,
  PRIMARY KEY (`departamentoAsignaturaId`),
  KEY `departamentoId` (`departamentoId`),
  KEY `asignaturaId` (`asignaturaId`),
  CONSTRAINT `departamentoasignatura_ibfk_1` FOREIGN KEY (`departamentoId`) REFERENCES `departamentos` (`departamentoId`),
  CONSTRAINT `departamentoasignatura_ibfk_2` FOREIGN KEY (`asignaturaId`) REFERENCES `asignaturas` (`asignaturaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.departamentoasignatura: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `departamentoasignatura` DISABLE KEYS */;
/*!40000 ALTER TABLE `departamentoasignatura` ENABLE KEYS */;

-- Volcando estructura para tabla grados.departamentos
DROP TABLE IF EXISTS `departamentos`;
CREATE TABLE IF NOT EXISTS `departamentos` (
  `departamentoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`departamentoId`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.departamentos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;

-- Volcando estructura para tabla grados.despachoprofesor
DROP TABLE IF EXISTS `despachoprofesor`;
CREATE TABLE IF NOT EXISTS `despachoprofesor` (
  `despachoProfesorId` int(11) NOT NULL AUTO_INCREMENT,
  `despachoId` int(11) NOT NULL,
  `profesorId` int(11) NOT NULL,
  PRIMARY KEY (`despachoProfesorId`),
  KEY `despachoId` (`despachoId`),
  KEY `profesorId` (`profesorId`),
  CONSTRAINT `despachoprofesor_ibfk_1` FOREIGN KEY (`despachoId`) REFERENCES `despachos` (`despachoId`),
  CONSTRAINT `despachoprofesor_ibfk_2` FOREIGN KEY (`profesorId`) REFERENCES `profesores` (`profesorId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.despachoprofesor: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `despachoprofesor` DISABLE KEYS */;
/*!40000 ALTER TABLE `despachoprofesor` ENABLE KEYS */;

-- Volcando estructura para tabla grados.despachos
DROP TABLE IF EXISTS `despachos`;
CREATE TABLE IF NOT EXISTS `despachos` (
  `despachoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Planta` int(11) NOT NULL,
  PRIMARY KEY (`despachoId`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `Planta` (`Planta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.despachos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `despachos` DISABLE KEYS */;
/*!40000 ALTER TABLE `despachos` ENABLE KEYS */;

-- Volcando estructura para tabla grados.espaciosaulas
DROP TABLE IF EXISTS `espaciosaulas`;
CREATE TABLE IF NOT EXISTS `espaciosaulas` (
  `aulaId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `planta` int(11) NOT NULL,
  `capacidad` int(11) NOT NULL,
  `tieneProyector` tinyint(1) NOT NULL,
  `tieneAltavoces` tinyint(1) NOT NULL,
  PRIMARY KEY (`aulaId`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `planta` (`planta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.espaciosaulas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `espaciosaulas` DISABLE KEYS */;
/*!40000 ALTER TABLE `espaciosaulas` ENABLE KEYS */;

-- Volcando estructura para tabla grados.espaciosdespachos
DROP TABLE IF EXISTS `espaciosdespachos`;
CREATE TABLE IF NOT EXISTS `espaciosdespachos` (
  `despachoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Planta` int(11) NOT NULL,
  PRIMARY KEY (`despachoId`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `Planta` (`Planta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.espaciosdespachos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `espaciosdespachos` DISABLE KEYS */;
/*!40000 ALTER TABLE `espaciosdespachos` ENABLE KEYS */;

-- Volcando estructura para tabla grados.estudiantes
DROP TABLE IF EXISTS `estudiantes`;
CREATE TABLE IF NOT EXISTS `estudiantes` (
  `estudianteId` int(11) NOT NULL AUTO_INCREMENT,
  `metodoAcceso` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `dni` char(9) COLLATE latin1_spanish_ci NOT NULL,
  `firstnombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `surnombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `birthDate` date NOT NULL,
  `email` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`estudianteId`),
  UNIQUE KEY `dni` (`dni`),
  CONSTRAINT `invalidStudentmetodoAcceso` CHECK (`metodoAcceso` in ('Selectividad','Ciclo','Mayor','Titulado Extranjero'))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.estudiantes: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `estudiantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `estudiantes` ENABLE KEYS */;

-- Volcando estructura para tabla grados.grados
DROP TABLE IF EXISTS `grados`;
CREATE TABLE IF NOT EXISTS `grados` (
  `gradoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `anyos` int(11) NOT NULL DEFAULT 4,
  PRIMARY KEY (`gradoId`),
  UNIQUE KEY `nombre` (`nombre`),
  CONSTRAINT `invalidDegreeanyos` CHECK (`anyos` >= 3 and `anyos` <= 5)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.grados: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `grados` DISABLE KEYS */;
/*!40000 ALTER TABLE `grados` ENABLE KEYS */;

-- Volcando estructura para tabla grados.groups
DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `groupId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `activity` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `year` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  PRIMARY KEY (`groupId`),
  UNIQUE KEY `name` (`name`,`year`,`subjectId`),
  KEY `subjectId` (`subjectId`),
  CONSTRAINT `groups_ibfk_1` FOREIGN KEY (`subjectId`) REFERENCES `subjects` (`subjectId`),
  CONSTRAINT `negativeGroupYear` CHECK (`year` > 0),
  CONSTRAINT `invalidGroupActivity` CHECK (`activity` in ('Teoria','Laboratorio'))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.groups: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;

-- Volcando estructura para tabla grados.groupsstudents
DROP TABLE IF EXISTS `groupsstudents`;
CREATE TABLE IF NOT EXISTS `groupsstudents` (
  `groupStudentId` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  PRIMARY KEY (`groupStudentId`),
  UNIQUE KEY `groupId` (`groupId`,`studentId`),
  KEY `studentId` (`studentId`),
  CONSTRAINT `groupsstudents_ibfk_1` FOREIGN KEY (`groupId`) REFERENCES `groups` (`groupId`) ON DELETE CASCADE,
  CONSTRAINT `groupsstudents_ibfk_2` FOREIGN KEY (`studentId`) REFERENCES `students` (`studentId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.groupsstudents: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `groupsstudents` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupsstudents` ENABLE KEYS */;

-- Volcando estructura para tabla grados.grupoasignatura
DROP TABLE IF EXISTS `grupoasignatura`;
CREATE TABLE IF NOT EXISTS `grupoasignatura` (
  `grupoAsignaturaId` int(11) NOT NULL AUTO_INCREMENT,
  `grupoId` int(11) NOT NULL,
  `asignaturaId` int(11) NOT NULL,
  PRIMARY KEY (`grupoAsignaturaId`),
  KEY `grupoId` (`grupoId`),
  KEY `asignaturaId` (`asignaturaId`),
  CONSTRAINT `grupoasignatura_ibfk_1` FOREIGN KEY (`grupoId`) REFERENCES `grupos` (`grupoId`),
  CONSTRAINT `grupoasignatura_ibfk_2` FOREIGN KEY (`asignaturaId`) REFERENCES `asignaturas` (`asignaturaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.grupoasignatura: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `grupoasignatura` DISABLE KEYS */;
/*!40000 ALTER TABLE `grupoasignatura` ENABLE KEYS */;

-- Volcando estructura para tabla grados.grupos
DROP TABLE IF EXISTS `grupos`;
CREATE TABLE IF NOT EXISTS `grupos` (
  `grupoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `actividad` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `anyos` int(11) NOT NULL,
  `asignaturaId` int(11) NOT NULL,
  PRIMARY KEY (`grupoId`),
  UNIQUE KEY `nombre` (`nombre`,`anyos`,`asignaturaId`),
  KEY `asignaturaId` (`asignaturaId`),
  CONSTRAINT `grupos_ibfk_1` FOREIGN KEY (`asignaturaId`) REFERENCES `asignaturas` (`asignaturaId`),
  CONSTRAINT `negativeGroupanyos` CHECK (`anyos` > 0),
  CONSTRAINT `invalidGroupactividad` CHECK (`actividad` in ('Teoria','Laboratorio'))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.grupos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `grupos` DISABLE KEYS */;
/*!40000 ALTER TABLE `grupos` ENABLE KEYS */;

-- Volcando estructura para tabla grados.gruposalumnos
DROP TABLE IF EXISTS `gruposalumnos`;
CREATE TABLE IF NOT EXISTS `gruposalumnos` (
  `grupoalumnoId` int(11) NOT NULL AUTO_INCREMENT,
  `grupoId` int(11) NOT NULL,
  `alumnoId` int(11) NOT NULL,
  PRIMARY KEY (`grupoalumnoId`),
  UNIQUE KEY `grupoId` (`grupoId`,`alumnoId`),
  KEY `alumnoId` (`alumnoId`),
  CONSTRAINT `gruposalumnos_ibfk_1` FOREIGN KEY (`grupoId`) REFERENCES `grupos` (`grupoId`) ON DELETE CASCADE,
  CONSTRAINT `gruposalumnos_ibfk_2` FOREIGN KEY (`alumnoId`) REFERENCES `alumnos` (`alumnoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.gruposalumnos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `gruposalumnos` DISABLE KEYS */;
/*!40000 ALTER TABLE `gruposalumnos` ENABLE KEYS */;

-- Volcando estructura para tabla grados.gruposestudiantes
DROP TABLE IF EXISTS `gruposestudiantes`;
CREATE TABLE IF NOT EXISTS `gruposestudiantes` (
  `grupoestudianteId` int(11) NOT NULL AUTO_INCREMENT,
  `grupoId` int(11) NOT NULL,
  `estudianteId` int(11) NOT NULL,
  PRIMARY KEY (`grupoestudianteId`),
  UNIQUE KEY `grupoId` (`grupoId`,`estudianteId`),
  KEY `estudianteId` (`estudianteId`),
  CONSTRAINT `gruposestudiantes_ibfk_1` FOREIGN KEY (`grupoId`) REFERENCES `grupos` (`grupoId`) ON DELETE CASCADE,
  CONSTRAINT `gruposestudiantes_ibfk_2` FOREIGN KEY (`estudianteId`) REFERENCES `estudiantes` (`estudianteId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.gruposestudiantes: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `gruposestudiantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `gruposestudiantes` ENABLE KEYS */;

-- Volcando estructura para tabla grados.imparte
DROP TABLE IF EXISTS `imparte`;
CREATE TABLE IF NOT EXISTS `imparte` (
  `ImparteId` int(11) NOT NULL AUTO_INCREMENT,
  `creditos` double NOT NULL,
  `profesorId` int(11) NOT NULL,
  `grupoid` int(11) NOT NULL,
  PRIMARY KEY (`ImparteId`),
  KEY `profesorId` (`profesorId`),
  KEY `grupoid` (`grupoid`),
  CONSTRAINT `imparte_ibfk_1` FOREIGN KEY (`profesorId`) REFERENCES `profesores` (`profesorId`),
  CONSTRAINT `imparte_ibfk_2` FOREIGN KEY (`grupoid`) REFERENCES `grupos` (`grupoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.imparte: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `imparte` DISABLE KEYS */;
/*!40000 ALTER TABLE `imparte` ENABLE KEYS */;

-- Volcando estructura para tabla grados.notagrupo
DROP TABLE IF EXISTS `notagrupo`;
CREATE TABLE IF NOT EXISTS `notagrupo` (
  `notaGrupoId` int(11) NOT NULL AUTO_INCREMENT,
  `notaId` int(11) NOT NULL,
  `grupoId` int(11) NOT NULL,
  PRIMARY KEY (`notaGrupoId`),
  KEY `notaId` (`notaId`),
  KEY `grupoId` (`grupoId`),
  CONSTRAINT `notagrupo_ibfk_1` FOREIGN KEY (`notaId`) REFERENCES `notas` (`notaId`),
  CONSTRAINT `notagrupo_ibfk_2` FOREIGN KEY (`grupoId`) REFERENCES `grupos` (`grupoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.notagrupo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `notagrupo` DISABLE KEYS */;
/*!40000 ALTER TABLE `notagrupo` ENABLE KEYS */;

-- Volcando estructura para tabla grados.notas
DROP TABLE IF EXISTS `notas`;
CREATE TABLE IF NOT EXISTS `notas` (
  `notaId` int(11) NOT NULL AUTO_INCREMENT,
  `valor` decimal(4,2) NOT NULL,
  `convocatoria` int(11) NOT NULL,
  `conMatricula` tinyint(1) NOT NULL,
  `alumnoId` int(11) NOT NULL,
  `grupoId` int(11) NOT NULL,
  PRIMARY KEY (`notaId`),
  UNIQUE KEY `duplicatedCallGrade` (`convocatoria`,`alumnoId`,`grupoId`),
  KEY `alumnoId` (`alumnoId`),
  KEY `grupoId` (`grupoId`),
  CONSTRAINT `notas_ibfk_1` FOREIGN KEY (`alumnoId`) REFERENCES `alumnos` (`alumnoId`),
  CONSTRAINT `notas_ibfk_2` FOREIGN KEY (`grupoId`) REFERENCES `grupos` (`grupoId`) ON DELETE CASCADE,
  CONSTRAINT `invalidGradevalor` CHECK (`valor` >= 0 and `valor` <= 10),
  CONSTRAINT `invalidconvocatoria` CHECK (`convocatoria` >= 1 and `convocatoria` <= 3)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.notas: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;

-- Volcando estructura para tabla grados.profesordepartamento
DROP TABLE IF EXISTS `profesordepartamento`;
CREATE TABLE IF NOT EXISTS `profesordepartamento` (
  `profesorDepartamentoId` int(11) NOT NULL AUTO_INCREMENT,
  `profesorId` int(11) NOT NULL,
  `departamentoId` int(11) NOT NULL,
  PRIMARY KEY (`profesorDepartamentoId`),
  KEY `profesorId` (`profesorId`),
  KEY `departamentoId` (`departamentoId`),
  CONSTRAINT `profesordepartamento_ibfk_1` FOREIGN KEY (`profesorId`) REFERENCES `profesores` (`profesorId`),
  CONSTRAINT `profesordepartamento_ibfk_2` FOREIGN KEY (`departamentoId`) REFERENCES `departamentos` (`departamentoId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.profesordepartamento: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `profesordepartamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `profesordepartamento` ENABLE KEYS */;

-- Volcando estructura para tabla grados.profesores
DROP TABLE IF EXISTS `profesores`;
CREATE TABLE IF NOT EXISTS `profesores` (
  `profesorId` int(11) NOT NULL AUTO_INCREMENT,
  `despachoId` int(11) NOT NULL,
  `departamentoId` int(11) NOT NULL,
  `dni` char(9) COLLATE latin1_spanish_ci NOT NULL,
  `nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `apellidos` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `categoria` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `emailProfesor` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`profesorId`),
  UNIQUE KEY `dni` (`dni`),
  KEY `despachoId` (`despachoId`),
  KEY `departamentoId` (`departamentoId`),
  CONSTRAINT `profesores_ibfk_1` FOREIGN KEY (`despachoId`) REFERENCES `despachos` (`despachoId`),
  CONSTRAINT `profesores_ibfk_2` FOREIGN KEY (`departamentoId`) REFERENCES `departamentos` (`departamentoId`),
  CONSTRAINT `categoriaInvalida` CHECK (`categoria` in ('Catedratico','Titular de Universidad','Profesor Contrato Doctor','Profesor Ayudante Doctor'))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.profesores: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `profesores` DISABLE KEYS */;
/*!40000 ALTER TABLE `profesores` ENABLE KEYS */;

-- Volcando estructura para tabla grados.profesortutoria
DROP TABLE IF EXISTS `profesortutoria`;
CREATE TABLE IF NOT EXISTS `profesortutoria` (
  `profesorTutoriaId` int(11) NOT NULL AUTO_INCREMENT,
  `citaId` int(11) NOT NULL,
  `tutoriaId` int(11) NOT NULL,
  PRIMARY KEY (`profesorTutoriaId`),
  KEY `citaId` (`citaId`),
  KEY `tutoriaId` (`tutoriaId`),
  CONSTRAINT `profesortutoria_ibfk_1` FOREIGN KEY (`citaId`) REFERENCES `citas` (`citaId`),
  CONSTRAINT `profesortutoria_ibfk_2` FOREIGN KEY (`tutoriaId`) REFERENCES `tutorias` (`tutoriaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.profesortutoria: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `profesortutoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `profesortutoria` ENABLE KEYS */;

-- Volcando estructura para procedimiento grados.spInsertarAsignatura
DROP PROCEDURE IF EXISTS `spInsertarAsignatura`;
DELIMITER //
CREATE DEFINER=`iissi_user`@`localhost` PROCEDURE `spInsertarAsignatura`(
IN `curso` INT,
IN `nombre` VARCHAR(255),
IN `codigo` VARCHAR(7),
IN `creditos` INT,
IN `tipo` VARCHAR(31),
IN `departamento` VARCHAR(255),
IN `vigencia` TINYINT

)
    MODIFIES SQL DATA
    DETERMINISTIC
BEGIN

insert into asignaturas(
curso,
nombre,
codigo,
creditos,
tipo,
departamento,
vigencia)
values (
curso,
nombre,
codigo,
creditos,
tipo,
departamento,
vigencia);
END//
DELIMITER ;

-- Volcando estructura para procedimiento grados.spInsertarDatosAsignaturas
DROP PROCEDURE IF EXISTS `spInsertarDatosAsignaturas`;
DELIMITER //
CREATE DEFINER=`iissi_user`@`localhost` PROCEDURE `spInsertarDatosAsignaturas`()
    MODIFIES SQL DATA
BEGIN
CALL spInsertarAsignatura('1', 'Álgebra Lineal y Numérica', '2060006', '6', 'Formación Básica', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('1', 'Cálculo Infinitesimal y Numérico', '2060003', '6', 'Formación Básica', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('1', 'Administración de Empresas', '2060002', '6', 'Formación Básica', 'ORGANIZACIÓN INDUSTRIAL Y GESTIÓN DE EMPRESAS I', '1');
CALL spInsertarAsignatura('1', 'Circuitos Electrónicos Digitales', '2060004', '6', 'Formación Básica', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('1', 'Estadística', '2060007', '6', 'Formación Básica', 'ESTADÍSTICA E INVESTIGACIÓN OPERATIVA', '1');
CALL spInsertarAsignatura('1', 'Estructura de Computadores', '2060008', '6', 'Formación Básica', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('1', 'Fundamentos de Programación', '2060001', '12', 'Formación Básica', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('1', 'Fundamentos Físicos de la Informática', '2060009', '6', 'Formación Básica', 'FÍSICA APLICADA I', '1');
CALL spInsertarAsignatura('1', 'Introducción a la Matemática Discreta', '2060005', '6', 'Formación Básica', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('2', 'Análisis y Diseño de Datos y Algoritmos', '2060010', '12', 'Obligatoria', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('2', 'Lógica Informática', '2060012', '6', 'Optativa', 'CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL', '1');
CALL spInsertarAsignatura('2', 'Matemática Discreta', '2060013', '6', 'Obligatoria', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('2', 'Redes de Computadores', '2060014', '6', 'Obligatoria', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('2', 'Arquitectura de Computadores', '2060015', '6', 'Obligatoria', 'ARQUITECTURA Y TECNOLOGÍA DE COMPUTADORES', '1');
CALL spInsertarAsignatura('2', 'Arquitectura de Redes', '2060016', '6', 'Optativa', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('2', 'Sistemas Operativos', '2060017', '6', 'Obligatoria', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('2', 'Introducción a la Ingeniería del Software y los Sistemas de Información I', '2060054', '6', 'Obligatoria', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('2', 'Introducción a la Ingeniería del Software y los Sistemas de Información II', '2060055', '6', 'Obligatoria', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('3', 'Configuración Implementación y Mantenimiento de Sistemas Informáticos', '2060018', '6', 'Optativa', 'ARQUITECTURA Y TECNOLOGÍA DE COMPUTADORES', '1');
CALL spInsertarAsignatura('3', 'Gestión de Sistemas de Información', '2060019', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('3', 'Gestión y Estrategia Empresarial', '2060020', '6', 'Optativa', 'ORGANIZACIÓN INDUSTRIAL Y GESTIÓN DE EMPRESAS I', '1');
CALL spInsertarAsignatura('3', 'Inteligencia Artificial', '2060021', '6', 'Obligatoria', 'CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL', '1');
CALL spInsertarAsignatura('3', 'Procesadores de Lenguajes', '2060022', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('3', 'Programación Declarativa', '2060023', '6', 'Optativa', 'CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL', '1');
CALL spInsertarAsignatura('3', 'Tecnologías Avanzadas de la Información', '2060024', '6', 'Optativa', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('3', 'Ampliación de Inteligencia Artificial', '2060025', '6', 'Optativa', 'CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL', '1');
CALL spInsertarAsignatura('3', 'Arquitectura de Sistemas Distribuidos', '2060026', '6', 'Optativa', 'ARQUITECTURA Y TECNOLOGÍA DE COMPUTADORES', '1');
CALL spInsertarAsignatura('3', 'Matemática Aplicada a Sistemas de Información', '2060027', '6', 'Optativa', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('3', 'Sistemas de Información Empresiales', '2060028', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('3', 'Sistemas Inteligentes', '2060029', '6', 'Optativa', 'CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL', '1');
CALL spInsertarAsignatura('3', 'Sistemas Orientados a Servicios', '2060030', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Prácticas Externas', '2060031', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Acceso Inteligente a la Información', '2060032', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Administración de Sistemas de Información', '2060033', '6', 'Optativa', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('4', 'Gestión de Procesos y Servicios', '2060034', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Infraestructura de Sistemas de Información', '2060035', '6', 'Optativa', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('4', 'Integración de Sistemas Físicos e Informáticos', '2060036', '6', 'Optativa', 'FÍSICA APLICADA I', '0');
CALL spInsertarAsignatura('4', 'Interacción Persona-ordenador', '2060037', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Matemática Aplicada a Tecnologías de la Información', '2060038', '6', 'Optativa', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('4', 'Matemáticas para la Computación', '2060039', '6', 'Optativa', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('4', 'Planificación y Gestión de Proyectos Informáticos', '2060040', '6', 'Obligatoria', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('4', 'Procesamiento de Imágenes Digitales', '2060041', '6', 'Optativa', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('4', 'Seguridad en Sistemas Informáticos y en Internet', '2060042', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Teledetección', '2060043', '6', 'Optativa', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('4', 'Aplicaciones de Soft Computing', '2060044', '6', 'Optativa', 'ELECTRÓNICA Y ELECTROMAGNETISMO', '1');
CALL spInsertarAsignatura('4', 'Computación Móvil', '2060045', '6', 'Optativa', 'ARQUITECTURA Y TECNOLOGÍA DE COMPUTADORES', '1');
CALL spInsertarAsignatura('4', 'Criptografía', '2060046', '6', 'Optativa', 'MATEMÁTICA APLICADA I', '1');
CALL spInsertarAsignatura('4', 'Estadística Computacional', '2060047', '6', 'Optativa', 'ESTADÍSTICA E INVESTIGACIÓN OPERATIVA', '1');
CALL spInsertarAsignatura('4', 'Gestión de la Producción', '2060048', '6', 'Optativa', 'ORGANIZACIÓN INDUSTRIAL Y GESTIÓN DE EMPRESAS I', '1');
CALL spInsertarAsignatura('4', 'Inteligencia Empresarial', '2060049', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Modelado y Análisis de Requisitos en Sistemas de Información', '2060050', '6', 'Optativa', 'LENGUAJES Y SISTEMAS INFORMÁTICOS', '1');
CALL spInsertarAsignatura('4', 'Modelos de Computación y Complejidad', '2060051', '6', 'Optativa', 'CIENCIAS DE LA COMPUTACIÓN E INTELIGENCIA ARTIFICIAL', '1');
CALL spInsertarAsignatura('4', 'Tecnología Informática y Sociedad', '2060052', '6', 'Optativa', 'TECNOLOGÍA ELECTRÓNICA', '1');
CALL spInsertarAsignatura('4', 'Trabajo Fin de Grado', '2060053', '12', 'Trabajo fin de grado', 'TECNOLOGÍA ELECTRÓNICA', '1');

END//
DELIMITER ;

-- Volcando estructura para tabla grados.students
DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `studentId` int(11) NOT NULL AUTO_INCREMENT,
  `accessMethod` varchar(30) COLLATE latin1_spanish_ci NOT NULL,
  `dni` char(9) COLLATE latin1_spanish_ci NOT NULL,
  `firstName` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `surname` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `birthDate` date NOT NULL,
  `email` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`studentId`),
  UNIQUE KEY `dni` (`dni`),
  UNIQUE KEY `email` (`email`),
  CONSTRAINT `invalidStudentAccessMethod` CHECK (`accessMethod` in ('Selectividad','Ciclo','Mayor','Titulado Extranjero'))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.students: ~21 rows (aproximadamente)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
REPLACE INTO `students` (`studentId`, `accessMethod`, `dni`, `firstName`, `surname`, `birthDate`, `email`) VALUES
	(1, 'Selectividad', '12345678A', 'Daniel', 'Pérez', '1991-01-01', 'daniel@alum.us.es'),
	(2, 'Selectividad', '22345678A', 'Rafael', 'Ramírez', '1992-01-01', 'rafael@alum.us.es'),
	(3, 'Selectividad', '32345678A', 'Gabriel', 'Hernández', '1993-01-01', 'gabriel@alum.us.es'),
	(4, 'Selectividad', '42345678A', 'Manuel', 'Fernández', '1994-01-01', 'manuel@alum.us.es'),
	(5, 'Selectividad', '52345678A', 'Joel', 'Gómez', '1995-01-01', 'joel@alum.us.es'),
	(6, 'Selectividad', '62345678A', 'Abel', 'López', '1996-01-01', 'abel@alum.us.es'),
	(7, 'Selectividad', '72345678A', 'Azael', 'González', '1997-01-01', 'azael@alum.us.es'),
	(8, 'Selectividad', '8345678A', 'Uriel', 'Martínez', '1998-01-01', 'uriel@alum.us.es'),
	(9, 'Selectividad', '92345678A', 'Gael', 'Sánchez', '1999-01-01', 'gael@alum.us.es'),
	(10, 'Titulado Extranjero', '12345678B', 'Noel', 'Álvarez', '1991-02-02', 'noel@alum.us.es'),
	(11, 'Titulado Extranjero', '22345678B', 'Ismael', 'Antúnez', '1992-02-02', 'ismael@alum.us.es'),
	(12, 'Titulado Extranjero', '32345678B', 'Nathanael', 'Antolinez', '1993-02-02', 'nathanael@alum.us.es'),
	(13, 'Titulado Extranjero', '42345678B', 'Ezequiel', 'Aznárez', '1994-02-02', 'ezequiel@alum.us.es'),
	(14, 'Titulado Extranjero', '52345678B', 'Ángel', 'Chávez', '1995-02-02', 'angel@alum.us.es'),
	(15, 'Titulado Extranjero', '62345678B', 'Matusael', 'Gutiérrez', '1996-02-02', 'matusael@alum.us.es'),
	(16, 'Titulado Extranjero', '72345678B', 'Samael', 'Gálvez', '1997-02-02', 'samael@alum.us.es'),
	(17, 'Titulado Extranjero', '82345678B', 'Baraquiel', 'Ibáñez', '1998-02-02', 'baraquiel@alum.us.es'),
	(18, 'Titulado Extranjero', '92345678B', 'Otoniel', 'Idiáquez', '1999-02-02', 'otoniel@alum.us.es'),
	(19, 'Titulado Extranjero', '12345678C', 'Niriel', 'Benítez', '1991-03-03', 'niriel@alum.us.es'),
	(20, 'Titulado Extranjero', '22345678C', 'Múriel', 'Bermúdez', '1992-03-03', 'muriel@alum.us.es'),
	(21, 'Titulado Extranjero', '32345678C', 'John', 'AII', '2000-01-01', 'john@alum.us.es');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;

-- Volcando estructura para tabla grados.subjects
DROP TABLE IF EXISTS `subjects`;
CREATE TABLE IF NOT EXISTS `subjects` (
  `subjectId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `acronym` varchar(8) COLLATE latin1_spanish_ci NOT NULL,
  `credits` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `type` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `degreeId` int(11) NOT NULL,
  PRIMARY KEY (`subjectId`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `acronym` (`acronym`),
  KEY `degreeId` (`degreeId`),
  CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`degreeId`) REFERENCES `degrees` (`degreeId`),
  CONSTRAINT `negativeSubjectCredits` CHECK (`credits` > 0),
  CONSTRAINT `invalidSubjectCourse` CHECK (`course` > 0 and `course` < 6),
  CONSTRAINT `invalidSubjectType` CHECK (`type` in ('Formacion Basica','Optativa','Obligatoria'))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.subjects: ~13 rows (aproximadamente)
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
REPLACE INTO `subjects` (`subjectId`, `name`, `acronym`, `credits`, `course`, `type`, `degreeId`) VALUES
	(1, 'Diseño y Pruebas', 'DP', 12, 3, 'Obligatoria', 1),
	(2, 'Acceso Inteligente a la Informacion', 'AII', 6, 4, 'Optativa', 1),
	(3, 'Optimizacion de Sistemas', 'OS', 6, 4, 'Optativa', 1),
	(4, 'Ingeniería de Requisitos', 'IR', 6, 2, 'Obligatoria', 1),
	(5, 'Análisis y Diseño de Datos y Algoritmos', 'ADDA', 12, 2, 'Obligatoria', 1),
	(6, 'Introducción a la Matematica Discreta', 'IMD', 6, 1, 'Formacion Basica', 2),
	(7, 'Redes de Computadores', 'RC', 6, 2, 'Obligatoria', 2),
	(8, 'Teoría de Grafos', 'TG', 6, 3, 'Obligatoria', 2),
	(9, 'Aplicaciones de Soft Computing', 'ASC', 6, 4, 'Optativa', 2),
	(10, 'Fundamentos de Programación', 'FP', 12, 1, 'Formacion Basica', 3),
	(11, 'Lógica Informatica', 'LI', 6, 2, 'Optativa', 3),
	(12, 'Gestión y Estrategia Empresarial', 'GEE', 90, 3, 'Optativa', 3),
	(13, 'Trabajo de Fin de Grado', 'TFG', 12, 4, 'Obligatoria', 3);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;

-- Volcando estructura para tabla grados.tutorias
DROP TABLE IF EXISTS `tutorias`;
CREATE TABLE IF NOT EXISTS `tutorias` (
  `tutoriaId` int(11) NOT NULL AUTO_INCREMENT,
  `profesorId` int(11) NOT NULL,
  `dia` date NOT NULL,
  `horaComienzo` time NOT NULL,
  `horaFin` time NOT NULL,
  PRIMARY KEY (`tutoriaId`),
  KEY `profesorId` (`profesorId`),
  CONSTRAINT `tutorias_ibfk_1` FOREIGN KEY (`profesorId`) REFERENCES `profesores` (`profesorId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla grados.tutorias: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `tutorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `tutorias` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
